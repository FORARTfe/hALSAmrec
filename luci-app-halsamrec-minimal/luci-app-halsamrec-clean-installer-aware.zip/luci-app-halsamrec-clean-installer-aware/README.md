# HALSAmRec Audio Devices LuCI Interface

LuCI web interface for:
- checking recorder service status
- starting and stopping the recorder service
- probing ALSA hardware parameters for `hw:0,0`

## Features

- recorder service start/stop toggle
- real-time status refresh every 3 seconds
- probe button disabled while recorder is running
- raw `arecord --dump-hw-params -D hw:0,0` output

## Installation

1. Copy `luci-app-halsamrec` into the OpenWrt build tree under `package/`
2. Enable it in `make menuconfig`
3. Build with `make package/luci-app-halsamrec/compile`
4. Install the generated `.ipk` on the target device

## Menu path

`Admin -> Audio Devices`

## Notes

This installer-aware variant assumes hALSAmrec was installed beforehand with `Installer.sh`.
It therefore does not declare `+alsa-utils` explicitly, while still relying on `arecord` and `/etc/init.d/autorecorder` at runtime.
The controller avoids `pgrep` and scans `/proc` directly, so it does not add a separate runtime assumption on procps-ng.
